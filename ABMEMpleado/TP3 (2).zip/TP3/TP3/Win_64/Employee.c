#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"

Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadaStr,char* sueldo)
{
    return 1;
}


Employee* employee_new()
{
    return NULL;
}

int employee_delete(Employee* this)
{
    if(this!=NULL)
    {
        free(this);
    }

   return 1;
}
