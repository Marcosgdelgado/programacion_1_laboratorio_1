#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/


int main()
{
    int option = 0;
    LinkedList* listaEmpleados = ll_newLinkedList();
    printf("Seleccione opcion:\n1) Cargar los datos desde el archivo csv (modo texto)\n8) Guardar los datos de los empleados en el archivo data.csv(modo texto)\n9) Guardar los datos de los empleados en el archivo data.csv(modo binario)\n \n");
    scanf("%d",&option);
    do{
        switch(option)
        {
            case 1:
                controller_loadFromText("data.csv",listaEmpleados);
                //controller_saveAsText("data.csv",listaEmpleados);
                break;
            case 8:
                //controller_loadFromText("data.csv",listaEmpleados);
                controller_saveAsText("data.csv",listaEmpleados);
                break;
            case 9:
                //controller_loadFromText("data.csv",listaEmpleados);
                controller_saveAsBinary("data.bin",listaEmpleados);
                break;
        }
    }while(option != 10);
    return 0;
}
