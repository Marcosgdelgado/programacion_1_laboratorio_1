#include "Empleado.h"
//#include "LinkedList.h"

void em_calcularSueldo(void* p)
{

}
