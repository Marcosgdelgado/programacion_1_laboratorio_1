#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"

Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadaStr,char* sueldo)
{
    return NULL;
}


