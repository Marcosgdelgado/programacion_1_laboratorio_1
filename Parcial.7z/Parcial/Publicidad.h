#ifndef PUBLICIDAD_H_INCLUDED
#define PUBLICIDAD_H_INCLUDED
#define Nombre_LEN 20

typedef struct{
int id;
int isempty;
char cuit;
int dias;
char archivo[Nombre_LEN];
}Publicidad;


#endif // PUBLICIDAD_H_INCLUDED
