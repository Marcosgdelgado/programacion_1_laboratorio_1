#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Pantalla.h"
#include "Publicidad.h"
#include "Utn_String.h"
#define Nombre_LEN 20
//prototipos privados
static int generarId(void);
//declarar como variable global
/*int idMax=0;
int generarId(void)
{
    return idMax++;
}
//Opcion dos
//declarar como variable global
static int idMax=0;
static int generarId(void)
{
    return idMax++;
}*/
//opcion 3
// int idMax=0;
 static int generarId(void)
{
    static int idMax =0 ;
    return idMax++;
}


int pantalla_inicializar(Pantalla *arrayPantalla,int len)
{
    int i;
    int ret=-1;
    if(arrayPantalla != NULL && len >= 0)
    {
        for(i=0;i<len;i++)
        {
            arrayPantalla[i].isEmpty=1;
            arrayPantalla[i].id = generarId();
            ret=0;
        }
    }
    return ret;
}
int pantalla_lugarLibre(Pantalla *arrayPantalla,int len,int *lugarLibre)
{
    int i;
    int ret=-1;
    if(arrayPantalla != NULL && len >= 0)
    {
        for(i=0; i<len ; i++)
        {
            if(arrayPantalla[i].isEmpty==1)
            {
                *lugarLibre = i;
                ret=0;
                break;
            }
        }
    }
    return ret;
}

int pantalla_alta(Pantalla *arrayPantalla,int len)
{
    int ret=-1;
    int flag=1; // 0 falso(dio mal) 1 verdadero(dio bien)
    int lugarLibre;
    int auxTipo;
    int auxPrecio;
    char auxNombre[Nombre_LEN];
    char auxDireccion[Nombre_LEN];


    if(arrayPantalla != NULL && len >= 0)
    {
        if(pantalla_lugarLibre(arrayPantalla,30,&lugarLibre)==0)
        {
            if(getString(auxNombre,"Ingrese un nombre: \n", "ERROR!\n", 1, Nombre_LEN, 2)!=0)
            {
                flag=0;
            }
            if(getString(auxDireccion,"Ingrese direccion: \n", "ERROR!\n", 1, Nombre_LEN, 2)!=0)
            {
                flag=0;
            }
            if(getValidInt("ingrese 1 para led normal 2 para led gigante\n","error\n",&auxTipo,1,2,2)!=0)
            {
                flag=0;
            }
            if(getValidInt("ingrese el precio en dolares\n","error\n",&auxPrecio,1,30000,2)!=0)
            {
                flag=0;
            }

            if(flag==1)
            {
                strncpy(arrayPantalla[lugarLibre].nombre,auxNombre,Nombre_LEN);
                strncpy(arrayPantalla[lugarLibre].direccion,auxDireccion,Nombre_LEN);
                arrayPantalla[lugarLibre].tipo=auxTipo;
                arrayPantalla[lugarLibre].precio=auxPrecio;
                arrayPantalla[lugarLibre].id;
                arrayPantalla[lugarLibre].isEmpty=0;
                ret=0;
            }
            else
            {
                printf("error, campo mal ingresado, la pantalla no se guardara");
                arrayPantalla[lugarLibre].isEmpty=1;
            }

            printf("\nDireccion: %s\nNombre: %s\nTipo de Pantalla: %d\nPrecio USD: %dn",arrayPantalla[lugarLibre].direccion,arrayPantalla[lugarLibre].nombre,arrayPantalla[lugarLibre].tipo,arrayPantalla[lugarLibre].precio);
            printf("ID: %d\n",arrayPantalla[lugarLibre].id);
            printf("%d\n",arrayPantalla[lugarLibre].isEmpty);
        }

    }
    return ret;
}

int pantalla_baja(Pantalla *arrayPantalla,int len)
{
    int ret=-1;
    int idPantalla;

    if(arrayPantalla != NULL && len >= 0)
    {
        if(getValidInt("Ingrese el legajo a ser borrado","error",&idPantalla,0,30,2)!=0)
        {
            printf("el legajo debe ser numerico\n");
        }
        if(arrayPantalla[idPantalla].isEmpty==1)
        {
            printf("esa posicion esta vacia\n");
        }
        else
        {
            arrayPantalla[idPantalla].isEmpty=1;
            ret=0;
        }
    }
    return ret;
}
int pantalla_Modificar(Pantalla *arrayPantalla,int len)
{
    int ret=-1;
    int flag=1; // 0 falso(dio mal) 1 verdadero(dio bien)
    int lugarLibre;
    int auxTipo;
    int auxPrecio;
    char auxNombre[Nombre_LEN];
    char auxDireccion[Nombre_LEN];


        if(pantalla_lugarLibre(arrayPantalla,30,&lugarLibre)==0)
        {

            if(getString(auxNombre,"Ingrese nuevo nombre: \n", "ERROR!\n", 1, Nombre_LEN, 2)==0)
            {
                flag=0;
            }
            if(getString(auxDireccion,"Ingrese nuevo direccion: \n", "ERROR!\n", 1, Nombre_LEN, 2)==0)
            {
                flag=0;
            }
            if(getValidInt("ingrese 1 para led normal 2 para led gigante\n","error\n",&auxTipo,1,2,2)==0)
            {
                flag=0;
            }
            if(getValidInt("ingrese el precio en dolares\n","error\n",&auxPrecio,1,30000,2)!=0)
            {
                flag=0;
            }

            if(flag==1)
            {
                strncpy(arrayPantalla[lugarLibre].nombre,auxNombre,Nombre_LEN);
                strncpy(arrayPantalla[lugarLibre].direccion,auxDireccion,Nombre_LEN);
                arrayPantalla[lugarLibre].tipo=auxTipo;
                arrayPantalla[lugarLibre].precio=auxPrecio;
                arrayPantalla[lugarLibre].isEmpty=0;
                ret=0;
            }
            else
            {
                printf("error, campo mal ingresado, la pantalla no se guardara");
                arrayPantalla[lugarLibre].isEmpty=1;
            }

            printf("\nDireccion: %s\nNombre: %s\nTipo de Pantalla: %d\nPrecio USD: %d\n",arrayPantalla[lugarLibre].direccion,arrayPantalla[lugarLibre].nombre,arrayPantalla[lugarLibre].tipo,arrayPantalla[lugarLibre].precio);
            printf("ID: %d\n",lugarLibre);
            printf("%d\n",arrayPantalla[lugarLibre].isEmpty);
        }

    return ret;
}
int mostrarPantalla(Pantalla *arrayPantalla, int len)
{

    system("cls");
    printf("proximoId   Nombre  Sexo   Sueldo     Sector\n\n");

    for(int i=0; i < len; i++)
    {

        if( arrayPantalla[i].isEmpty == 0)
        {
            arrayPantalla[i].nombre;
        }
    }

    printf("\n\n");
    return 0;
}
