#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Pantalla.h"
#include "Publicidad.h"
#include "Utn_String.h"
#define Nombre_LEN 20


int main()
{
    int menu();
    Pantalla arrayPantalla[30];
    pantalla_inicializar(arrayPantalla,30);
    int caca=0;
    do
    {
        pantalla_alta(arrayPantalla,30);
        /*switch(menu())
        {
        case 1:
            pantalla_alta(arrayPantalla,30);
            break;
        case 2:
            pantalla_baja(arrayPantalla,30);
            break;
        case 3:
            pantalla_Modificar(arrayPantalla,30);
            //system("pause");
            break;
         case 4:
            mostrarPantalla(arrayPantalla,30);
            //system("pause");
            break;

        case 5:
            system("cls");
                printf("Fin del programa\n");
                system("pause>>null");
                break;
        }*/
        caca++;
    }while(caca<3);
    /*
    int auxTipo=0;
    getValidInt("ingrese el precio en dolares\n","error\n",&auxTipo,1,3000,2);
    printf("%d",auxTipo);
    */
    return 0;

}
int menu()
{
    int opcion;

    system("cls");
    printf("\n*** Menu de Opciones ***\n\n");
    printf(" 1-  Alta\n");
    printf(" 2-  Baja\n");
    printf(" 3-  Modificacion\n");
    printf(" 4-  Mostrar\n");
    printf(" 5- Salir\n\n");
    printf(" Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}
