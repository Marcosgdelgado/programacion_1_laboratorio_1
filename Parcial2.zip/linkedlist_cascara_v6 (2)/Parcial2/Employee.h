#ifndef EMPLOYEE_H_INCLUDED
#define EMPLOYEE_H_INCLUDED
typedef struct
{
    int id;
    char nombre[128];
    int horasTrabajadas;
    float sueldo;
}Employee;

Employee* employee_new();

int employee_delete(Employee*  this);

void employee_setId(Employee* this,int id);
int employee_getId(Employee* this);

void employee_setNombre(Employee* this,char* nombre);
char* employee_getNombre(Employee* this);

void employee_setHorasTrabajadas(Employee* this,int horasTrabajadas);
int employee_getHorasTrabajadas(Employee* this);

void employee_setSueldo(Employee* this,float sueldo);
float employee_getSueldo(Employee* this);

Employee* employee_newParametros(char *var1, char *var2, char *var3, char *var4);



#endif // EMPLOYEE_H_INCLUDED
