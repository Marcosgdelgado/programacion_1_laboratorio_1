#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "input.h"
#include "Employee.h"
#include "LinkedList.h"

Venta* Venta_new(){
    Venta* peliculas = malloc(sizeof(Venta));
    return peliculas;
}
int Venta_delete(Venta* this){
    int retorno = -1;
    if(this!=NULL)
    {
    free(this);
    retorno=0;
    }
    return retorno;
}
Venta* Venta_newParametros(char *var1, char *var2, char *var3, char *var4, char *var5, char *var6)
{
    int idAux,nombreAux,diaAux,horarioAux,salaAux,cantidadAux;
    Venta* p = Venta_new();
    idAux = atoi(var1);
    diaAux = atoi(var3);
    salaAux = atoi(var5);
    cantidadAux = atoi(var6);


    Venta_setId(p, idAux);
    Venta_setNombre(p, var2);
    Venta_setDia(p, diaAux);
    Venta_setHorario(p, var4);
    //Venta_setSueldo(p, horarioAux);
    Venta_setSala(p, salaAux);
    Venta_setCantidad(p,cantidadAux);

    return p;
}

/********FUNCIONES SET***********/

void Venta_setId(Venta* this, int id)
{
    if(id > 0)
        this->id = id;
}

void Venta_setNombre(Venta* this, char* nombre)
{
    if(nombre[0] != '\0')
    strncpy(this->nombre, nombre, sizeof(this->nombre));
}

/*void Venta_setSueldo(Venta* this, int horario)
{
    if(horario > 0)
        this->horario = horario;
}*/

void Venta_setDia(Venta* this, int dia)
{
    if(dia > 0)
        this->dia = dia;
}

void Venta_setHorario(Venta* this, char* horario)
{
    if(horario[0] != '\0')
    strncpy(this->horario, horario, sizeof(this->horario));
}

void Venta_setSala(Venta* this, int sala)
{
    if(sala>0)
    {
        this->sala = sala;
    }
}
void Venta_setCantidad(Venta* this, int cantidad_entradas)
{
    if (cantidad_entradas>0)
    {
        this->cantidad_entradas = cantidad_entradas;
    }
}
/*********FUNCIONES GET**********/

int Venta_getId(Venta* this)
{
    return this->id;
}

char * Venta_getNombre(Venta* this)
{
    return this->nombre;
}

char * Venta_getHorario(Venta* this)
{
    return this->horario;
}

int Venta_getSueldo(Venta* this)
{
    return this->horario;
}

int Venta_getDia(Venta* this)
{
    return this->dia;
}

int Venta_getSala(Venta* this)
{
    return this->sala;
}

int Venta_getCantidad(Venta* this)
{
    return this->cantidad_entradas;
}

int set_monto(Venta* pVenta)
{
    int todoOk=0;
    //Venta* auxVenta;
    int multiplicar;
    int total;
    int multiplicar2;
    int total2;
    //eDominio* dom =pDominio;
    if(pVenta->dia == 1 || pVenta->dia == 2 || pVenta->dia == 3 )
    {
        //printf("LLEGO");
        multiplicar = pVenta->monto= 240;
        total = multiplicar * pVenta->cantidad_entradas;
        //printf("%d\n", total);
        todoOk=total;
    }
    else
    {
        multiplicar2=pVenta->monto=350;
        total2= multiplicar2 * pVenta->cantidad_entradas;
        todoOk=total2
        ;
    }
    return todoOk;
}
