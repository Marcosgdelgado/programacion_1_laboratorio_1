#ifndef Venta_H_INCLUDED
#define Venta_H_INCLUDED
typedef struct
{
    int id;
    char nombre[128];
    int dia;
    char horario[10];
    int sala;
    int cantidad_entradas;
    int monto;

}Venta;

Venta* Venta_new();

int Venta_delete(Venta*  this);

void Venta_setId(Venta* this,int id);
int Venta_getId(Venta* this);

void Venta_setNombre(Venta* this,char* nombre);
char* Venta_getNombre(Venta* this);

void Venta_setDia(Venta* this,int dia);
int Venta_getDia(Venta* this);

void Venta_setSueldo(Venta* this,int horario);
int Venta_getSueldo(Venta* this);

void Venta_setHorario(Venta* this, char* horario);
char* Venta_getHorario(Venta* this);

void Venta_setSala(Venta* this,int sala);
int Venta_getSala(Venta* this);

void Venta_setCantidad(Venta* this,int cantidad_entradas);
int Venta_getCantidad(Venta* this);

int set_monto(Venta* this);

Venta* Venta_newParametros(char *var1, char *var2, char *var3, char *var4, char *var5,char *var6);

#endif // Venta_H_INCLUDED
