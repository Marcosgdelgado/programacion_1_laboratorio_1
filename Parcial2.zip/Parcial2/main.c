#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"
#include "parser.h"
#include "controller.h"
#include "input.h"
#include "LinkedList.h"
int main()
{
    int opcion= 0;
    int flag = 0;
    LinkedList* listaVentas = ll_newLinkedList();
    opcion = menu();
    do{
        switch(opcion)
        {
            case 1:
                system("cls");
                if (flag == 1){
                    printf ("\n\nSolo se puede cargar una vez\n\n");
                }else{
                    controller_loadFromText("data.csv",listaVentas);
                }
                flag = 1;
                break;
            case 2:
                if (flag == 1){
                system("cls");
                //controller_ListVenta(listaVentas);
                controller_imprimirEmpleados(listaVentas);
                system("pause");
                system("cls");
                }
                break;
//            case 7:
//                system("cls");
//                controller_sortVenta(listaVentas);
//                break;
            case 3:
                system("cls");
                controller_saveAsText("dataVenta.csv", listaVentas);
                //sumaCosto(listaVentas);
                //controllerSAVEINFORMES("dataLL.csv",listaVentas);
                break;
            case 4:
                //ll_map(listaVentas,set_monto);
                //controller_imprimirEmpleados(listaVentas);
                //controller_Informe(listaVentas);
                //sumaCosto(listaVentas);
                //sumacostos(listaVentas);
                system("pause");
               break;
        }
    opcion = menu();
    }while(opcion != 5);
    return 0;
}
