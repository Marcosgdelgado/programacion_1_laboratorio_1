#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"
#include "LinkedList.h"
#include "parser.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */

int parser_VentaFromText(FILE* pFile , LinkedList* pArrayListVenta){
    int r,i=0;
    char var1[20],var2[20],var3[20],var4[20],var5[20],var6[20];
    Venta* auxVenta;
    if (pFile == NULL){
        printf ("Error al leer el archivo");
    }
    else{
        //leo los titulos
        r = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5,var6);
        //Se saco la lectura en falso, ya que sino el primer empleado con indice 1, pasaria
        //a estar en el indice 0 del linked list
        while( !feof(pFile))
        {
            r = fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n",var1,var2,var3,var4,var5,var6);
            if(r==6)
            {

                auxVenta = Venta_newParametros(var1,var2,var3,var4,var5,var6);
                i++;
                ll_add(pArrayListVenta,auxVenta);
            }
            else
                break;
        }
    }
    return i;
}

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
int parser_VentaFromBinary(FILE* pFile , LinkedList* pArrayListVenta)
{
    int r,i;
    Venta* pBinario;

        do{
                pBinario = Venta_new(); //se coloca dentro del do porque sino pisa los otros datos dentro del linkedlist
                if(fread(pBinario,sizeof(Venta),1, pFile)==1)
                {
                    ll_add(pArrayListVenta,pBinario);
                }
                   else
                   {
                       Venta_delete(pBinario);
                   }


            }while( !feof(pFile));

    return i;
}
