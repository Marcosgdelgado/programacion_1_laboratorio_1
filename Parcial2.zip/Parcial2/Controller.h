#ifndef CONTROLLER_H_INCLUDED
#define CONTROLLER_H_INCLUDED
#include "LinkedList.h"

int controller_loadFromText(char* path , LinkedList* this);
int controller_loadFromBinary(char* path , LinkedList* this);
int controller_addVenta(LinkedList* this);
int controller_editVenta(LinkedList* this);
int controller_removeVenta(LinkedList* this);
int controller_ListVenta(LinkedList* this);
int controller_sortVenta(LinkedList* this);
int controller_saveAsText(char* path , LinkedList* this);
int controller_saveAsBinary(char* path , LinkedList* this);
int controller_saveAsTexTo(char* path, LinkedList* this);
int controller_ListEntregas(LinkedList* this);
int controller_imprimirEmpleados(LinkedList* this);
int controller_genLLamadas(char* path, LinkedList* this);
int sumacostos(void*);
int sumaCosto (LinkedList* pArrayListVenta);
int menu(void);
int controller_Informe(LinkedList* this);


#endif // CONTROLLER_H_INCLUDED
