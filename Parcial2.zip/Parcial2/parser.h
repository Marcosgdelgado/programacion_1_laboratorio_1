#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED
#include "LinkedList.h"

int parser_VentaFromText(FILE* pFile , LinkedList* pArrayListVenta);
int parser_VentaFromBinary(FILE* pFile , LinkedList* pArrayListVenta);

#endif // PARSER_H_INCLUDED
