#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"
#include "parser.h"
#include "controller.h"
#include "input.h"
#include "LinkedList.h"

int menu(void){
int option;
printf("\nSeleccione 1- Para cargar los datos de los envios en modo texo");
printf("\nSeleccione 2- Para imprimir la lista de envios");
printf("\nSeleccione 3- Para imprimir archivo de envios");
printf("\nSeleccione 4- Para calcular TOTAL envio");
printf("\nSeleccione 5- Para salir del programa");
printf("\nOpcion elegida: ");
scanf("%d",&option);
return option;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* pArrayListVenta)
{
    FILE* pArchivo;
    pArchivo = fopen(path,"r+");
    if(pArchivo == NULL){
        printf("Error al leer el archivo");
    }
    else{
        parser_VentaFromText(pArchivo,pArrayListVenta);
        printf("\n\nDatos cargados con Exito!\n\n");
    }
    fclose(pArchivo);
    return 0;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */

int controller_loadFromBinary(char* path , LinkedList* pArrayListVenta)
{
    FILE* pArchivo;
    pArchivo = fopen(path,"rb");
    if(pArchivo == NULL)
    {
        printf("Error al abrir el archivo");
    }
    else
    {
        parser_VentaFromBinary(pArchivo,pArrayListVenta);
        printf("\n\nDatos cargados con Exito!\n\n");

    }

    fclose(pArchivo);

return 0;
}


/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
int controller_addVenta(LinkedList* pArrayListVenta)
{
   Venta* pB;
   int resp,cant;
   char var1[20],var2[20],var3[20],var4[20],var5[20],var6 [20];
   resp = 1;
   while (resp == 1){
        cant = ll_len(pArrayListVenta);
        sprintf(var1,"%d",cant);
        printf("\nIngrese el nombre del empleado: ");
        fflush(stdin);
        getString(var2);
        printf("\nIngrese las horas trabajadas del empleado: ");
        fflush(stdin);
        getString(var3);
        printf("\nIngrese el horario del empleado: ");
        fflush(stdin);
        getString(var4);
        pB = Venta_newParametros(var1,var2,var3,var4,var5,var6);
        ll_add(pArrayListVenta,pB);
        printf("\nPara continuar ingresando datos ingrese 1 : ");
        getInt(&resp);
        system("cls");
   }
    return 1;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
/*int controller_editVenta(LinkedList* pArrayListVenta)
{
    int codigo,resp;
    char auxNombre[51];
    int auxSueldo,auxHoras;
    Venta* puntero;
    printf ("\nDesea imprimir la lista? Ingrese 1 para imprimir: ");
        getInt(&resp);
        if (resp == 1){
            controller_ListVenta(pArrayListVenta);
        }
    printf ("\nIngrese el codigo del empleado a modificar: ");
    getInt(&codigo);
    if (pArrayListVenta != NULL){
        puntero = ll_get(pArrayListVenta,codigo);
        printf("1-Para modificar el Nombre\t 2-Para el Sueldo\t 3-Para las Horas Trabajadas");
        getInt(&resp);
        switch(resp){
            case 1:
                printf("\nIngrese el nombre a asignar");
                getString(auxNombre);
                Venta_setNombre(puntero,auxNombre);
                break;
            case 2:
                printf("\nIngrese el horario a asignar");
                getInt(&auxSueldo);
                Venta_setSueldo(puntero,auxSueldo);
                break;
            case 3:
                printf("\nIngrese las horas trabajadas a asignar");
                getInt(&auxHoras);
                Venta_setDia(puntero,auxHoras);
                break;
            case 4:
                printf("\n\nIngrese el nombre a asignar");
                getString(auxNombre);
                Venta_setNombre(puntero,auxNombre);
                printf("\n\nIngrese el horario a asignar");
                getInt(&auxSueldo);
                Venta_setSueldo(puntero,auxSueldo);
                printf("\nIngrese las horas trabajadas a asignar");
                getInt(&auxHoras);
                Venta_setDia(puntero,auxHoras);
                break;
        }
    }


    return 1;
}
*/
/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
/*int controller_removeVenta(LinkedList* pArrayListVenta)
{
    int cant,codigo,resp;
    Venta* puntero;
    printf ("\nDesea imprimir la lista? Ingrese 1 para imprimir: ");
        getInt(&resp);
        if (resp == 1){
            controller_ListVenta(pArrayListVenta);
        }
    printf ("\nIngrese el codigo del empleado a borrar: ");
    getInt(&codigo);
    if (pArrayListVenta != NULL){
        cant = ll_len(pArrayListVenta);
        if (codigo >0 && codigo <= cant){
            puntero = ll_get(pArrayListVenta,codigo);
            free(puntero);
            ll_remove(pArrayListVenta,codigo);
            printf ("\nSe elimino correctamente\n");
            system("pause");
            system("cls");
        }
        else{
            printf("\nEl codigo debe estar entre 1 y %d\n\n",cant);
            system("pause");
            system("cls");
        }
    }
    else{
        printf("\n\nError al eliminar el registro \n\n");
    }
    return 1;
}*/

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
/*int controller_ListVenta(LinkedList* pArrayListVenta)
{
    int i,cant;
    cant = ll_len(pArrayListVenta);
    Venta* lista;
    for (i=1;i<cant;i++){
        lista = (Venta*)ll_get(pArrayListVenta,i);
        printf("%d\t %s\t %d\t %d\t %s\n",Venta_getId(lista),Venta_getNombre(lista),Vent_getDia(lista),Venta_getSueldo(lista),Venta_getHorario(lista));
    }
    return 1;
}*/

int controller_Informe(LinkedList* pArrayListVenta)
{
    int i,cant;
    int numSala;
    int ret=0;
    int acumuladoCant=0;
    int entrada=0;
    Venta* lista;
    printf("Ingrese numero de sala: ");
    scanf("%d", &numSala);
    cant = ll_len(pArrayListVenta);

    for(i=0;i<cant;i++)
    {
        lista = (Venta*)ll_get(pArrayListVenta,i);
        if(Venta_getSala(lista)==numSala)
        {
            entrada = Venta_getCantidad(lista);
            acumuladoCant= acumuladoCant + entrada;
            ret= 1;
        }
    }
    printf("Total entradas de sala %d : %d\n",numSala,acumuladoCant);
return ret;
}
int controller_imprimirEmpleados(LinkedList* pArrayListVenta)
{
    int i,cant;
    int ret=0;
    int km,total;
    cant = ll_len(pArrayListVenta);
    Venta* lista;
    printf("Id_Venta\t Nombre\t horario\t sala\t Cantidad\t Monto\t Dia\n");

    if(pArrayListVenta != NULL)
    {
        for (i=1;i<cant;i++)
        {

             lista = (Venta*)ll_get(pArrayListVenta,i);
                printf("%d\t  %s\t  %s\t %d\t %d\t %d\t",Venta_getId(lista),Venta_getNombre(lista),Venta_getHorario(lista),Venta_getSala(lista),Venta_getCantidad(lista),set_monto(lista));
                switch(Venta_getDia(lista))
                {
                    case 0:
                    printf("  Domingo\n");
                    break;
                    case 1:
                    printf("  Lunes\n");
                    break;
                    case 2:
                    printf("  Martes\n");
                    break;
                    case 3:
                    printf("  Miercoles\n");
                    break;
                    case 4:
                    printf("  Jueves\n");
                    break;
                    case 5:
                    printf("  Viernes\n");
                    break;
                    case 6:
                    printf("  Sabado\n");
                    break;
                }
        }
        ret = 1;
    }
    return ret;
}
            /*if(Venta_getDia(lista)< 50)
            {
                km = Venta_getDia(lista);

                total = km*67;
                switch(Venta_getSueldo(lista))
                {
                    case 1:
                   total= total + 330;
                    break;
                    case 2:
                    total = total + 560;
                    break;
                    case 3:
                    total = total + 80;
                    break;
                }
                printf("\t  %d\n",total);
            }else
            {
                km = Vent_getDia(lista);

                total = km*80;
                switch(Venta_getSueldo(lista))
                {
                    case 1:
                   total= total + 330;
                    break;
                    case 2:
                    total = total + 560;
                    break;
                    case 3:
                    total = total + 80;
                    break;
                }
                printf("\t%d\n",total);
            }/*
        //printf("%d\n",Venta_getSueldo(lista));
        }
        ret = 1;
    }
    return ret;
}

* \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *



int controller_sortVenta(LinkedList* pArrayListVenta)
{
    int i,j,len;
    Venta* actualEmpleado;
    Venta* empSiguiente;
    Venta* auxiliar;
    len = ll_len(pArrayListVenta);
    for (i=1;i<len;i++){
        actualEmpleado = ll_get(pArrayListVenta,i);
        for(j=i+1;j<len;j++){
            empSiguiente = ll_get(pArrayListVenta,j);
            if (Venta_getSueldo(actualEmpleado) > Venta_getSueldo(empSiguiente)){
                auxiliar = actualEmpleado;
                actualEmpleado = empSiguiente;
                empSiguiente = auxiliar;
            }
        }
    }
    return 1;
}


/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */


int controller_saveAsText(char* path , LinkedList* pArrayListVenta)//serializar escribir en el archivo lo que esta en memoria
{
    FILE* pArchivo;
    int len,i;
    int total= 0;
    int km,totalKM;
    Venta* auxVentas;
    len = ll_len(pArrayListVenta);
    pArchivo = fopen(path,"r+");

    if (pArchivo == NULL){
        pArchivo = fopen(path,"w+");
    }
    if (len>0)
    {
    fprintf(pArchivo,"Id_envio,nombre_pelicula,dia,horario,sala,cantidad_entradas,monto\n");
        for (i=1;i<len;i++)
        {
            auxVentas = ll_get(pArrayListVenta,i);
            //fprintf(pArchivo,"%d,%s,%d,%s,%d,%d\n",auxVentas->id,auxVentas->nombre,auxVentas->dia,auxVentas->horario,auxVentas->sala,auxVentas->cantidad_entradas);

            /*if(auxVentas->dia < 7)
            {
                    km= auxVentas->dia;
                    totalKM= km * 67;
                    switch(auxVentas->dia)
                {
                    case 1:
                   totalKM= totalKM + 330;
                    break;
                    case 2:
                    totalKM = totalKM + 560;
                    break;
                    case 3:
                    totalKM = totalKM + 80;
                    break;
                }
                    fprintf(pArchivo,"%d,%s,%d,%d,%d\n",auxVentas->id,auxVentas->nombre,auxVentas->dia,auxVentas->horario,totalKM);
            }else
                {
                    km= auxVentas->dia;
                    totalKM= km * 80;
                    switch(auxVentas->horario)
                {
                    case 1:
                   totalKM= totalKM + 330;
                    break;
                    case 2:
                    totalKM = totalKM + 560;
                    break;
                    case 3:
                    totalKM = totalKM + 80;
                    break;
                }
                    fprintf(pArchivo,"%d,%s,%d,%d,%d\n",auxVentas->id,auxVentas->nombre,auxVentas->dia,auxVentas->horario,totalKM);
                }*/
            total++;
        }
        printf("\nSe escribieron %d caracteres\n\n", total);
    }
    fclose(pArchivo);
    return 1;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListVenta LinkedList*
 * \return int
 *
 */
/*int controller_saveAsBinary(char* path , LinkedList* pArrayListVenta)
{
    FILE* pArchivo;
    int len,i;
    int total= 0;
    Venta* auxEmpleado;
    len = ll_len(pArrayListVenta);
    pArchivo = fopen(path,"wb");
    if (pArchivo == NULL){
        pArchivo = fopen(path,"wb");
    }
    if (len>0)
        {
        for (i=0;i<len;i++)
        {
        auxEmpleado = ll_get(pArrayListVenta,i);
        fwrite(auxEmpleado,sizeof(Venta),1,pArchivo);
        //fprintf(pArchivo,"%d,%s,%d,%d\n",auxEmpleado->id,auxEmpleado->nombre,auxEmpleado->dia,auxEmpleado->horario);
        total++;
        }
    printf("\nSe escribieron %d caracteres\n\n", total);
    }
    fclose(pArchivo);
    return 1;
}*/

/*int controller_genLLamadas(char* path, LinkedList* pArrayListVenta)
{
    FILE* pArchivo;

    int total= 0;
    int len;
    int opcion;
    int retorno=-1;
    Venta* auxEmpleado;
    len = ll_len(pArrayListVenta);
    pArchivo = fopen(path,"w+");

    printf("Ingrese numero (1 a 5): ");
    scanf("%d",&opcion);
    printf("%d",opcion);

    if(opcion >=1 && opcion<=5)
    {
        retorno = 1;
    }
*/
    /*if (pArchivo == NULL)
    {
        pArchivo = fopen(path,"w+");
    }
    //ll_filter(pArrayListVenta,1);
    if (len>0)
    {

        for (i=0;i<len;i++)
        {

                auxEmpleado = ll_get(pArrayListVenta,i);
                if(auxEmpleado->horario==opcion)
                {
                    fprintf(pArchivo,"%d, ",auxEmpleado->horario);
                    total++;
                }
        }
    printf("\nSe escribieron %d caracteres\n\n", total);
    }
    printf("\n%d", retorno);
    fclose(pArchivo);
    return retorno;
}*/

 /*int controllerSAVEINFORMES(char* path,LinkedList* pArrayListVenta)
{
    int i,cant;
    Venta* ellamada;
    LinkedList* axLinked;

    //axLinked= ll_filter(pArrayListVenta, controller_genLLamadas(path,pArrayListVenta));

    cant = ll_len(axLinked);
    Venta* lista;
    for (i=1;i<cant;i++)
    {
         lista = (Venta*)ll_get(axLinked,i);

            fprintf(path,"%d\t %s\t %d\t %s\t %d",Venta_getId(lista),Venta_getNombre(lista),Vent_getDia(lista)
                   ,Venta_getHorario(lista), Venta_getSueldo(lista));

        //printf("%d\n",Venta_getSueldo(lista));
    }
    return 1;
}*/

/*int coso (void* p)
{
    int ret=0;
    int cantidad;

    if(p!= NULL)
    {
        Venta_getHorario(p,)
    }
return ret;
}*/
/*int sumacostos(void* p)
{
    int ret=0;
    int cant,i;
    int auxVenta;
    int costoaux;
    cant = ll_len(p);
    Venta* costo;

    if (p!=NULL)
    {
        for(i=0;i<cant;i++)
        {
            //printf("%d",i);
          costoaux = ll_get(p,i);
          auxVenta = ll_map(p,costoaux);

          printf("%d", auxVenta);

        }
        ret = 1;
    }

    return ret;
}*/
/*
int sumaCosto(LinkedList* pArrayListVenta)
{
    int i,cant;
    int totalKM=0;
    int totalMAYOR=0;
    int km;
    cant = ll_len(pArrayListVenta);
    Venta* auxCostos;

    for (i=1;i<cant;i++)
        {
            auxCostos = ll_get(pArrayListVenta,i);
            if(auxCostos->dia < 50)
            {
                    km= auxCostos->dia;
                    totalKM= km * 67;
                    switch(auxCostos->horario)
                {
                    case 1:
                   totalKM= totalKM + 330;
                    break;
                    case 2:
                    totalKM = totalKM + 560;
                    break;
                    case 3:
                    totalKM = totalKM + 80;
                    break;
                }

            }else
                {
                    km= auxCostos->dia;
                    totalKM= km * 80;
                    switch(auxCostos->horario)
                {
                    case 1:
                   totalKM= totalKM + 330;
                    break;
                    case 2:
                    totalKM = totalKM + 560;
                    break;
                    case 3:
                    totalKM = totalKM + 80;
                    break;
                }

                }
           totalMAYOR = totalMAYOR + totalKM;
        }
    printf("\nTOTAL COSTO: %d\n", totalMAYOR);
    return 1;
}*/
